package com.arkan.cadpro;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private CadView cad; private EditText command; private TextView status; private boolean english=false;
    private final ArrayList<PointF> points = new ArrayList<>();
    private static final int CREATE_KML=41, CREATE_DXF=42;
    @Override public void onCreate(Bundle b){ super.onCreate(b); buildUi(); }
    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(28,30,34));
        LinearLayout top=new LinearLayout(this); top.setPadding(8,8,8,8); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=new TextView(this); title.setText("ARKAN CAD PRO  |  V1.0"); title.setTextColor(Color.WHITE); title.setTextSize(18); title.setTypeface(null,1); top.addView(title,new LinearLayout.LayoutParams(0,48,1));
        Button lang=button("عربي / EN"); lang.setOnClickListener(v->{english=!english; refreshLabels();}); top.addView(lang); root.addView(top);
        LinearLayout tools=new LinearLayout(this); tools.setPadding(5,3,5,3);
        addTool(tools,"LINE",()->{cad.mode="LINE";say(english?"Tap two points to draw a line":"المس نقطتين لرسم خط");});
        addTool(tools,"PLINE",()->{cad.mode="PLINE";say(english?"Tap points; use DONE to finish":"حدد النقاط ثم DONE للإنهاء");});
        addTool(tools,"UNDO",()->{if(!points.isEmpty()){points.remove(points.size()-1);cad.invalidate();}});
        addTool(tools,"KML",()->new AlertDialog.Builder(this).setTitle("KML Export").setMessage(english?"KML requires a defined geographic coordinate system (WGS84 / UTM). This prototype does not guess coordinates.":"يتطلب تصدير KML تحديد نظام إحداثيات جغرافي صحيح (WGS84 / UTM). لن يخمّن البرنامج الإحداثيات.").setPositiveButton("OK",null).show());
        addTool(tools,"DXF",()->exportDxf()); root.addView(tools);
        cad=new CadView(); root.addView(cad,new LinearLayout.LayoutParams(-1,0,1));
        status=new TextView(this); status.setTextColor(Color.LTGRAY); status.setPadding(10,5,10,5); status.setText("Ready  |  Offline mode"); root.addView(status);
        LinearLayout cmd=new LinearLayout(this); cmd.setPadding(6,6,6,8);
        command=new EditText(this); command.setSingleLine(true); command.setTextColor(Color.WHITE); command.setHintTextColor(Color.GRAY); command.setHint("Command: LINE / PLINE / UNDO / CLEAR"); command.setBackgroundColor(Color.rgb(48,51,57)); cmd.addView(command,new LinearLayout.LayoutParams(0,50,1));
        Button run=button("RUN"); run.setOnClickListener(v->runCommand()); cmd.addView(run); root.addView(cmd);
        setContentView(root);
    }
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(11);return b;}
    private void addTool(LinearLayout row,String label,Runnable action){Button b=button(label);b.setOnClickListener(v->action.run());row.addView(b,new LinearLayout.LayoutParams(0,48,1));}
    private void say(String s){status.setText(s);}
    private void refreshLabels(){say(english?"Ready | Offline mode":"جاهز | يعمل دون إنترنت");}
    private void runCommand(){String c=command.getText().toString().trim().toUpperCase(Locale.ROOT);command.setText("");switch(c){case "LINE":cad.mode="LINE";say("LINE: tap two points");break;case "PLINE":cad.mode="PLINE";say("PLINE: tap points, DONE to finish");break;case "DONE":cad.finishPolyline();break;case "UNDO":if(!points.isEmpty())points.remove(points.size()-1);cad.invalidate();break;case "CLEAR":points.clear();cad.invalidate();break;case "KML":say("KML requires geographic coordinates; configure CRS first.");break;case "DXF":exportDxf();break;default:say("Unknown command: "+c);}}
    private void exportDxf(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/dxf");i.putExtra(Intent.EXTRA_TITLE,"arkan_drawing.dxf");startActivityForResult(i,CREATE_DXF);}
    private String dxf(){StringBuilder s=new StringBuilder("0\nSECTION\n2\nENTITIES\n");for(int n=0;n+1<points.size();n+=2){PointF a=points.get(n),b=points.get(n+1);s.append("0\nLINE\n8\n0\n10\n").append(a.x).append("\n20\n").append(a.y).append("\n30\n0\n11\n").append(b.x).append("\n21\n").append(b.y).append("\n31\n0\n");}s.append("0\nENDSEC\n0\nEOF\n");return s.toString();}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;try(OutputStream out=getContentResolver().openOutputStream(data.getData())){if(out==null)return;out.write(dxf().getBytes("UTF-8"));say("DXF exported");}catch(Exception e){say("Export error: "+e.getMessage());}}
    class CadView extends View {Paint p=new Paint(3);String mode="LINE";float sx,sy;boolean first=false;PointF start;
        CadView(){super(MainActivity.this);setBackgroundColor(Color.rgb(17,19,22));}
        protected void onDraw(Canvas c){super.onDraw(c);p.setColor(Color.rgb(42,46,52));p.setStrokeWidth(1);for(int x=0;x<getWidth();x+=40)c.drawLine(x,0,x,getHeight(),p);for(int y=0;y<getHeight();y+=40)c.drawLine(0,y,getWidth(),y,p);p.setColor(Color.rgb(0,190,255));p.setStrokeWidth(3);for(int n=0;n+1<points.size();n+=2)c.drawLine(points.get(n).x,points.get(n).y,points.get(n+1).x,points.get(n+1).y,p);p.setColor(Color.WHITE);p.setTextSize(22);c.drawText("MODEL SPACE",18,30,p);}
        public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()==MotionEvent.ACTION_UP){PointF q=new PointF(e.getX(),e.getY());if(mode.equals("LINE")){if(!first){start=q;first=true;}else{points.add(start);points.add(q);first=false;invalidate();}}else{points.add(q);invalidate();}return true;}return true;}
        void finishPolyline(){mode="LINE";first=false;say("Polyline input finished (basic prototype)");}
    }
}
